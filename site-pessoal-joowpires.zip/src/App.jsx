export default function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1 style={{ color: '#f43f5e' }}>Olá, meu nome é</h1>
      <h2 style={{ fontSize: '2rem' }}>Joow Pires</h2>
      <p>Eu sou um desenvolvedor criando experiências digitais incríveis.</p>
    </div>
  );
}